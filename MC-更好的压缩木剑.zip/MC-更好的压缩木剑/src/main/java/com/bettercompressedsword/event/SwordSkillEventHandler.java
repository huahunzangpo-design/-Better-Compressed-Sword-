package com.bettercompressedsword.event;

import com.bettercompressedsword.BetterCompressedSword;
import com.bettercompressedsword.item.CompressedWoodenSwordItem;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 处理压缩木剑的战斗相关效果：
 * 1. 4级剑“金身”无敌期间的伤害拦截
 * 2. 4-6级剑的吸血（按造成伤害比例回血）
 * 3. 5/6级剑的击杀特效（灵魂粒子，6级附加剑气环）
 */
@Mod.EventBusSubscriber(modid = BetterCompressedSword.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class SwordSkillEventHandler {

    public static final String TAG_INVINCIBLE_UNTIL = "bcs_invincible_until";

    private SwordSkillEventHandler() {
    }

    // 金身：无敌期间取消所有伤害
    @SubscribeEvent
    public static void onLivingHurt(LivingHurtEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }

        Level level = player.level();
        if (level.isClientSide) {
            return;
        }

        long until = player.getPersistentData().getLong(TAG_INVINCIBLE_UNTIL);
        if (level.getGameTime() < until) {
            event.setCanceled(true);
        }
    }

    // 吸血：4级2%、5级3%、6级5%，按最终造成伤害回血
    @SubscribeEvent
    public static void onLivingHurtLifesteal(LivingHurtEvent event) {
        if (!(event.getSource().getEntity() instanceof ServerPlayer player)) {
            return;
        }
        ItemStack weapon = player.getMainHandItem();
        if (!(weapon.getItem() instanceof CompressedWoodenSwordItem sword)) {
            return;
        }
        if (event.getEntity() == player || event.getAmount() <= 0) {
            return;
        }

        float ratio = switch (sword.getLevel()) {
            case 4 -> 0.02F;
            case 5 -> 0.03F;
            case 6 -> 0.05F;
            default -> 0.0F;
        };
        if (ratio > 0) {
            player.heal(event.getAmount() * ratio);
        }
    }

    // 击杀特效：5级灵魂爆发，6级附加剑气环
    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (!(event.getSource().getEntity() instanceof ServerPlayer player)) {
            return;
        }
        if (!(player.getMainHandItem().getItem() instanceof CompressedWoodenSwordItem sword)) {
            return;
        }
        int level = sword.getLevel();
        if (level < 5) {
            return;
        }
        LivingEntity victim = event.getEntity();
        if (!(victim.level() instanceof ServerLevel serverLevel)) {
            return;
        }

        double x = victim.getX();
        double y = victim.getY() + victim.getBbHeight() * 0.5;
        double z = victim.getZ();

        serverLevel.sendParticles(ParticleTypes.SOUL, x, y, z, 12, 0.4, 0.5, 0.4, 0.06);
        serverLevel.playSound(null, x, y, z, SoundEvents.SOUL_ESCAPE, SoundSource.PLAYERS, 1.0F,
                level >= 6 ? 0.5F : 0.8F);

        if (level >= 6) {
            for (int i = 0; i < 12; i++) {
                double angle = Math.PI * 2 * i / 12;
                double px = x + Math.cos(angle) * 1.2;
                double pz = z + Math.sin(angle) * 1.2;
                serverLevel.sendParticles(ParticleTypes.SWEEP_ATTACK, px, y, pz, 1, 0, 0, 0, 0);
                serverLevel.sendParticles(ParticleTypes.FLAME, px, y + 0.3, pz, 2, 0, 0.1, 0, 0.02);
            }
        }
    }
}
