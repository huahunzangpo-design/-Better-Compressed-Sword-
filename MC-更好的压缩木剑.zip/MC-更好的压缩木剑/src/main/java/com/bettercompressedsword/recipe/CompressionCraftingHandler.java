package com.bettercompressedsword.recipe;

import com.bettercompressedsword.BetterCompressedSword;
import com.bettercompressedsword.item.ModItems;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = BetterCompressedSword.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class CompressionCraftingHandler {
    private CompressionCraftingHandler() {
    }

    @SubscribeEvent
    public static void onItemCrafted(PlayerEvent.ItemCraftedEvent event) {
        Player player = event.getEntity();
        if (player.level().isClientSide || !(event.getInventory() instanceof CraftingContainer container)) {
            return;
        }

        CompressionRecipe compressionRecipe = player.level().getRecipeManager()
                .getRecipeFor(ModRecipes.COMPRESSION_TYPE.get(), container, player.level())
                .orElse(null);
        if (compressionRecipe != null) {
            handleCompression(event, player, container, compressionRecipe);
            return;
        }

        SwordRecipe swordRecipe = player.level().getRecipeManager()
                .getRecipeFor(ModRecipes.SWORD_TYPE.get(), container, player.level())
                .orElse(null);
        if (swordRecipe != null) {
            handleSwordCrafting(event, player, container, swordRecipe);
        }
    }

    private static void handleCompression(PlayerEvent.ItemCraftedEvent event, Player player, CraftingContainer container, CompressionRecipe recipe) {
        int chance = recipe.getSuccessChance(container);
        boolean success = chance >= 100 || player.getRandom().nextInt(100) < chance;

        // 失败且有保护符：保护所有材料（补偿 ResultSlot 对每个非空格的 -1），仅保护符自身碎裂
        if (!success && hasTalisman(container)) {
            protectAllMaterials(container);
            event.getCrafting().setCount(0);
            player.displayClientMessage(Component.translatable(
                    "message.bettercompressedsword.compression.protected", chance), true);
            return;
        }

        // ResultSlot 会在此事件后从每个非空格中移除一个物品。
        // 给输入格额外保留 8 根，使本次净消耗正好 9 根；
        // 幸运石堆先缩为 1，确保整组都被消耗；保护符成功时不消耗（+1 抵消 -1）。
        for (int slot = 0; slot < container.getContainerSize(); slot++) {
            ItemStack stack = container.getItem(slot);
            if (stack.is(recipe.getInput())) {
                stack.setCount(stack.getCount() - (CompressionRecipe.REQUIRED_STICKS - 1));
            } else if (stack.is(ModItems.LUCKY_STONE.get())) {
                stack.setCount(1);
            } else if (stack.is(ModItems.COMPRESSION_TALISMAN.get())) {
                stack.setCount(stack.getCount() + 1);
            }
        }

        if (!success) {
            event.getCrafting().setCount(0);
        }

        player.displayClientMessage(Component.translatable(
                success ? "message.bettercompressedsword.compression.success"
                        : "message.bettercompressedsword.compression.failed",
                chance
        ), true);
    }

    private static void handleSwordCrafting(PlayerEvent.ItemCraftedEvent event, Player player, CraftingContainer container, SwordRecipe recipe) {
        int chance = recipe.getSuccessChance(container);
        boolean success = chance >= 100 || player.getRandom().nextInt(100) < chance;

        // 失败且有保护符：保护所有材料，仅保护符自身碎裂
        if (!success && hasTalisman(container)) {
            protectAllMaterials(container);
            event.getCrafting().setCount(0);
            player.displayClientMessage(Component.translatable(
                    "message.bettercompressedsword.sword.protected", chance), true);
            return;
        }

        // 木棍净消耗 2 根：先保留 1 根，让 ResultSlot 再移除 1 根；
        // 木板净消耗 1 个，先保留 1 个；幸运石整组消耗；保护符成功时不消耗。
        for (int slot = 0; slot < container.getContainerSize(); slot++) {
            ItemStack stack = container.getItem(slot);
            if (stack.is(recipe.getInputStick())) {
                stack.setCount(stack.getCount() - (SwordRecipe.REQUIRED_STICKS - 1));
            } else if (stack.is(ItemTags.PLANKS)) {
                stack.setCount(stack.getCount() - (SwordRecipe.REQUIRED_PLANKS - 1));
            } else if (stack.is(ModItems.LUCKY_STONE.get())) {
                stack.setCount(1);
            } else if (stack.is(ModItems.COMPRESSION_TALISMAN.get())) {
                stack.setCount(stack.getCount() + 1);
            }
        }

        if (!success) {
            event.getCrafting().setCount(0);
        }

        player.displayClientMessage(Component.translatable(
                success ? "message.bettercompressedsword.sword.success"
                        : "message.bettercompressedsword.sword.failed",
                chance
        ), true);
    }

    private static boolean hasTalisman(CraftingContainer container) {
        for (int slot = 0; slot < container.getContainerSize(); slot++) {
            if (container.getItem(slot).is(ModItems.COMPRESSION_TALISMAN.get())) {
                return true;
            }
        }
        return false;
    }

    private static void protectAllMaterials(CraftingContainer container) {
        for (int slot = 0; slot < container.getContainerSize(); slot++) {
            ItemStack stack = container.getItem(slot);
            if (!stack.isEmpty() && !stack.is(ModItems.COMPRESSION_TALISMAN.get())) {
                // +1 抵消 ResultSlot 对每个非空格的 -1，实现"零消耗"
                stack.setCount(stack.getCount() + 1);
            }
        }
    }
}
