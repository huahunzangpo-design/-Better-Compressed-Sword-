package com.bettercompressedsword.recipe;

import com.bettercompressedsword.item.ModItems;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import net.minecraft.core.NonNullList;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;

public final class SwordRecipe implements Recipe<CraftingContainer> {
    public static final int REQUIRED_STICKS = 2;
    public static final int REQUIRED_PLANKS = 1;
    public static final int LUCK_PER_STONE = 5;

    private final ResourceLocation id;
    private final int inputLevel;
    private final int baseChance;
    private final Item inputStick;
    private final ItemStack result;

    public SwordRecipe(ResourceLocation id, int inputLevel) {
        if (inputLevel < 1 || inputLevel > 6) {
            throw new IllegalArgumentException("Sword input level must be between 1 and 6");
        }
        this.id = id;
        this.inputLevel = inputLevel;
        this.baseChance = CompressionRecipe.getBaseChance(inputLevel);
        this.inputStick = ModItems.getCompressedStick(inputLevel);
        this.result = new ItemStack(ModItems.getCompressedSword(inputLevel));
    }

    @Override
    public boolean matches(CraftingContainer container, Level level) {
        if (container.getWidth() < 3 || container.getHeight() < 3) {
            return false;
        }
        int stickCount = 0;
        int plankSlots = 0;
        for (int slot = 0; slot < container.getContainerSize(); slot++) {
            ItemStack stack = container.getItem(slot);
            if (stack.isEmpty()) {
                continue;
            }
            if (stack.is(inputStick)) {
                stickCount += stack.getCount();
            } else if (stack.is(ItemTags.PLANKS)) {
                plankSlots++;
            } else if (!stack.is(ModItems.LUCKY_STONE.get()) && !stack.is(ModItems.COMPRESSION_TALISMAN.get())) {
                return false;
            }
        }
        return stickCount >= REQUIRED_STICKS && plankSlots == REQUIRED_PLANKS;
    }

    @Override
    public ItemStack assemble(CraftingContainer container, RegistryAccess registryAccess) {
        return result.copy();
    }

    @Override
    public boolean canCraftInDimensions(int width, int height) {
        return width >= 3 && height >= 3;
    }

    @Override
    public ItemStack getResultItem(RegistryAccess registryAccess) {
        return result;
    }

    @Override
    public NonNullList<Ingredient> getIngredients() {
        return NonNullList.of(Ingredient.EMPTY, Ingredient.of(inputStick), Ingredient.of(ItemTags.PLANKS));
    }

    @Override
    public NonNullList<ItemStack> getRemainingItems(CraftingContainer container) {
        return NonNullList.withSize(container.getContainerSize(), ItemStack.EMPTY);
    }

    @Override
    public ResourceLocation getId() {
        return id;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return ModRecipes.SWORD_SERIALIZER.get();
    }

    @Override
    public RecipeType<?> getType() {
        return ModRecipes.SWORD_TYPE.get();
    }

    public Item getInputStick() {
        return inputStick;
    }

    public int getInputLevel() {
        return inputLevel;
    }

    public int getBaseChance() {
        return baseChance;
    }

    public int getLuckyStoneCount(CraftingContainer container) {
        int count = 0;
        for (int slot = 0; slot < container.getContainerSize(); slot++) {
            ItemStack stack = container.getItem(slot);
            if (stack.is(ModItems.LUCKY_STONE.get())) {
                count += stack.getCount();
            }
        }
        return count;
    }

    public int getSuccessChance(CraftingContainer container) {
        return Math.min(100, baseChance + getLuckyStoneCount(container) * LUCK_PER_STONE);
    }

    public static final class Serializer implements RecipeSerializer<SwordRecipe> {
        @Override
        public SwordRecipe fromJson(ResourceLocation id, JsonObject json) {
            int inputLevel = GsonHelper.getAsInt(json, "input_level");
            try {
                return new SwordRecipe(id, inputLevel);
            } catch (IllegalArgumentException exception) {
                throw new JsonParseException(exception);
            }
        }

        @Override
        public SwordRecipe fromNetwork(ResourceLocation id, FriendlyByteBuf buffer) {
            return new SwordRecipe(id, buffer.readVarInt());
        }

        @Override
        public void toNetwork(FriendlyByteBuf buffer, SwordRecipe recipe) {
            buffer.writeVarInt(recipe.inputLevel);
        }
    }
}
