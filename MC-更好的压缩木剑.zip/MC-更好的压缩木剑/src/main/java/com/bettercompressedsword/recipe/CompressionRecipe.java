package com.bettercompressedsword.recipe;

import com.bettercompressedsword.item.ModItems;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import net.minecraft.core.NonNullList;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;

public final class CompressionRecipe implements Recipe<CraftingContainer> {
    public static final int REQUIRED_STICKS = 9;
    public static final int LUCK_PER_STONE = 5;

    private final ResourceLocation id;
    private final int inputLevel;
    private final int baseChance;
    private final Item input;
    private final ItemStack result;

    public CompressionRecipe(ResourceLocation id, int inputLevel, int baseChance) {
        if (inputLevel < 0 || inputLevel >= 6) {
            throw new IllegalArgumentException("Compression input level must be between 0 and 5");
        }
        if (baseChance < 0 || baseChance > 100) {
            throw new IllegalArgumentException("Compression base chance must be between 0 and 100");
        }
        this.id = id;
        this.inputLevel = inputLevel;
        this.baseChance = baseChance;
        this.input = inputLevel == 0 ? Items.STICK : ModItems.getCompressedStick(inputLevel);
        this.result = new ItemStack(ModItems.getCompressedStick(inputLevel + 1));
    }

    public static int getBaseChance(int inputLevel) {
        return switch (inputLevel) {
            case 0, 1 -> 100;
            case 2 -> 85;
            case 3 -> 60;
            case 4 -> 45;
            // 六级剑复用五级木棍的压缩成功率
            case 5, 6 -> 30;
            default -> throw new IllegalArgumentException("No compression recipe for input level " + inputLevel);
        };
    }

    @Override
    public boolean matches(CraftingContainer container, Level level) {
        if (container.getWidth() < 3 || container.getHeight() < 3) {
            return false;
        }

        boolean foundInput = false;
        for (int slot = 0; slot < container.getContainerSize(); slot++) {
            ItemStack stack = container.getItem(slot);
            if (stack.isEmpty()) {
                continue;
            }
            if (stack.is(input)) {
                if (foundInput || stack.getCount() < REQUIRED_STICKS) {
                    return false;
                }
                foundInput = true;
            } else if (!stack.is(ModItems.LUCKY_STONE.get()) && !stack.is(ModItems.COMPRESSION_TALISMAN.get())) {
                return false;
            }
        }
        return foundInput;
    }

    @Override
    public ItemStack assemble(CraftingContainer container, RegistryAccess registryAccess) {
        return result.copy();
    }

    @Override
    public boolean canCraftInDimensions(int width, int height) {
        return width >= 3 && height >= 3;
    }

    @Override
    public ItemStack getResultItem(RegistryAccess registryAccess) {
        return result;
    }

    @Override
    public NonNullList<Ingredient> getIngredients() {
        return NonNullList.of(Ingredient.EMPTY, Ingredient.of(input));
    }

    @Override
    public NonNullList<ItemStack> getRemainingItems(CraftingContainer container) {
        return NonNullList.withSize(container.getContainerSize(), ItemStack.EMPTY);
    }

    @Override
    public ResourceLocation getId() {
        return id;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return ModRecipes.COMPRESSION_SERIALIZER.get();
    }

    @Override
    public RecipeType<?> getType() {
        return ModRecipes.COMPRESSION_TYPE.get();
    }

    public Item getInput() {
        return input;
    }

    public int getInputLevel() {
        return inputLevel;
    }

    public int getBaseChance() {
        return baseChance;
    }

    public int getLuckyStoneCount(CraftingContainer container) {
        int count = 0;
        for (int slot = 0; slot < container.getContainerSize(); slot++) {
            ItemStack stack = container.getItem(slot);
            if (stack.is(ModItems.LUCKY_STONE.get())) {
                count += stack.getCount();
            }
        }
        return count;
    }

    public int getSuccessChance(CraftingContainer container) {
        return Math.min(100, baseChance + getLuckyStoneCount(container) * LUCK_PER_STONE);
    }

    public static final class Serializer implements RecipeSerializer<CompressionRecipe> {
        @Override
        public CompressionRecipe fromJson(ResourceLocation id, JsonObject json) {
            int inputLevel = GsonHelper.getAsInt(json, "input_level");
            int baseChance = GsonHelper.getAsInt(json, "base_chance");
            try {
                return new CompressionRecipe(id, inputLevel, baseChance);
            } catch (IllegalArgumentException exception) {
                throw new JsonParseException(exception);
            }
        }

        @Override
        public CompressionRecipe fromNetwork(ResourceLocation id, FriendlyByteBuf buffer) {
            return new CompressionRecipe(id, buffer.readVarInt(), buffer.readVarInt());
        }

        @Override
        public void toNetwork(FriendlyByteBuf buffer, CompressionRecipe recipe) {
            buffer.writeVarInt(recipe.inputLevel);
            buffer.writeVarInt(recipe.baseChance);
        }
    }
}
