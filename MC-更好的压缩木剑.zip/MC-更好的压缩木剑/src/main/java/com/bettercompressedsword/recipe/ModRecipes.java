package com.bettercompressedsword.recipe;

import com.bettercompressedsword.BetterCompressedSword;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModRecipes {
    public static final DeferredRegister<RecipeSerializer<?>> RECIPE_SERIALIZERS =
            DeferredRegister.create(ForgeRegistries.RECIPE_SERIALIZERS, BetterCompressedSword.MODID);
    public static final DeferredRegister<RecipeType<?>> RECIPE_TYPES =
            DeferredRegister.create(Registries.RECIPE_TYPE, BetterCompressedSword.MODID);

    public static final RegistryObject<RecipeSerializer<CompressionRecipe>> COMPRESSION_SERIALIZER =
            RECIPE_SERIALIZERS.register("compression", CompressionRecipe.Serializer::new);
    public static final RegistryObject<RecipeType<CompressionRecipe>> COMPRESSION_TYPE =
            RECIPE_TYPES.register("compression", () -> new RecipeType<>() {
            });

    public static final RegistryObject<RecipeSerializer<SwordRecipe>> SWORD_SERIALIZER =
            RECIPE_SERIALIZERS.register("sword_compression", SwordRecipe.Serializer::new);
    public static final RegistryObject<RecipeType<SwordRecipe>> SWORD_TYPE =
            RECIPE_TYPES.register("sword_compression", () -> new RecipeType<>() {
            });

    private ModRecipes() {
    }
}
