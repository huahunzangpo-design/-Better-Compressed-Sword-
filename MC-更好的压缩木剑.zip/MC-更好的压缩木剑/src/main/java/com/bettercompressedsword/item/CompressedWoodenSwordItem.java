package com.bettercompressedsword.item;

import com.bettercompressedsword.BetterCompressedSword;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.List;
import java.util.Set;

public final class CompressedWoodenSwordItem extends SwordItem {
    public static final String TAG_COOLDOWN = "bcs_cooldown_until";

    private static final int BUFF_DURATION = 100;

    // 过于破坏平衡的效果，不随剑等级自动施加
    // 注：Java版不存在"飞行"效果（创造飞行由 Abilities 实现，非 MobEffect），故无需屏蔽
    private static final Set<MobEffect> DISABLED_EFFECTS = Set.of(
            MobEffects.HEALTH_BOOST,
            MobEffects.REGENERATION,
            MobEffects.HEAL,
            MobEffects.SATURATION,
            MobEffects.LEVITATION,
            MobEffects.INVISIBILITY
    );

    // 技能持续时间（tick）
    private static final int INVINCIBLE_DURATION = 5 * 20;
    // 技能冷却时间（tick）
    private static final int COOLDOWN_LEVEL4 = 30 * 20;
    private static final int COOLDOWN_LEVEL5 = 20 * 20;
    private static final int COOLDOWN_LEVEL6 = 15 * 20;

    private final int level;

    // 六级剑授予的全部有益效果，惰性缓存以避免每 tick 遍历注册表
    private static List<MobEffect> beneficialEffects;

    public CompressedWoodenSwordItem(int level, Tier tier, int attackDamage, float attackSpeed, Properties properties) {
        super(tier, attackDamage, attackSpeed, properties);
        this.level = level;
    }

    public int getLevel() {
        return level;
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slotId, boolean isSelected) {
        if (level.isClientSide || !(entity instanceof Player player) || stack != player.getMainHandItem()) {
            return;
        }

        applyBuffs(player);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (this.level < 4) {
            return InteractionResultHolder.pass(stack);
        }

        long now = level.getGameTime();
        long cooldownUntil = stack.getOrCreateTag().getLong(TAG_COOLDOWN);
        if (now < cooldownUntil) {
            int remain = (int) ((cooldownUntil - now) / 20);
            if (!level.isClientSide) {
                player.displayClientMessage(Component.translatable("message.bettercompressedsword.skill.cooldown", remain), true);
            }
            return InteractionResultHolder.fail(stack);
        }

        boolean activated = switch (this.level) {
            case 4 -> activateInvincible(level, player, stack);
            case 5 -> activateDash(level, player, stack);
            case 6 -> activateSwordWave(level, player, stack);
            default -> false;
        };

        if (activated) {
            player.awardStat(Stats.ITEM_USED.get(this));
            grantSkillAdvancement(level, player);
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        return InteractionResultHolder.pass(stack);
    }

    private static void grantSkillAdvancement(Level level, Player player) {
        if (level.isClientSide || !(player instanceof ServerPlayer serverPlayer)) {
            return;
        }
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath(BetterCompressedSword.MODID, "unlock_power");
        var advancement = serverPlayer.server.getAdvancements().getAdvancement(id);
        if (advancement != null) {
            serverPlayer.getAdvancements().award(advancement, "use_skill");
        }
    }

    // 四级：短暂无敌（金身）
    private boolean activateInvincible(Level level, Player player, ItemStack stack) {
        if (!level.isClientSide) {
            long until = level.getGameTime() + INVINCIBLE_DURATION;
            player.getPersistentData().putLong("bcs_invincible_until", until);
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.TOTEM_USE, SoundSource.PLAYERS, 1.0F, 1.0F);
            setCooldown(stack, level, COOLDOWN_LEVEL4);
            player.displayClientMessage(Component.translatable("message.bettercompressedsword.skill.invincible"), true);
        }
        return true;
    }

    // 五级：冲刺攻击
    private boolean activateDash(Level level, Player player, ItemStack stack) {
        if (!level.isClientSide) {
            var look = player.getLookAngle();
            player.setDeltaMovement(look.x * 2.5, look.y * 0.5 + 0.4, look.z * 2.5);
            player.hurtMarked = true;
            player.fallDistance = 0.0F;

            AABB box = player.getBoundingBox().inflate(2.0);
            List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, box,
                    e -> e != player && e.isAlive());
            float damage = 15.0F + this.level * 2.0F;
            for (LivingEntity target : targets) {
                double dx = target.getX() - player.getX();
                double dz = target.getZ() - player.getZ();
                double dist = Math.sqrt(dx * dx + dz * dz) + 0.0001;
                target.hurt(level.damageSources().playerAttack(player), damage);
                target.knockback(1.2F, -dx / dist, -dz / dist);
            }
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.0F, 1.0F);
            setCooldown(stack, level, COOLDOWN_LEVEL5);
            player.displayClientMessage(Component.translatable("message.bettercompressedsword.skill.dash"), true);
        }
        return true;
    }

    // 六级：范围剑气
    private boolean activateSwordWave(Level level, Player player, ItemStack stack) {
        if (!level.isClientSide) {
            AABB box = player.getBoundingBox().inflate(8.0);
            List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, box,
                    e -> e != player && e.isAlive());
            float damage = 50.0F + this.level * 5.0F;
            for (LivingEntity target : targets) {
                double dx = target.getX() - player.getX();
                double dz = target.getZ() - player.getZ();
                double dist = Math.sqrt(dx * dx + dz * dz) + 0.0001;
                target.hurt(level.damageSources().playerAttack(player), damage);
                target.knockback(2.5F, -dx / dist, -dz / dist);
                target.setSecondsOnFire(5);
            }
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.5F, 0.8F);
            setCooldown(stack, level, COOLDOWN_LEVEL6);
            player.displayClientMessage(Component.translatable("message.bettercompressedsword.skill.wave"), true);
        }
        return true;
    }

    private void setCooldown(ItemStack stack, Level level, int ticks) {
        stack.getOrCreateTag().putLong(TAG_COOLDOWN, level.getGameTime() + ticks);
    }

    @Override
    public boolean isEnchantable(ItemStack stack) {
        return true;
    }

    @Override
    public int getEnchantmentValue() {
        return 12 + level * 2;
    }

    private void applyBuffs(Player player) {
        if (level >= 4) {
            addEffect(player, MobEffects.DAMAGE_BOOST, 0);
        }
        if (level >= 6) {
            for (MobEffect effect : getBeneficialEffects()) {
                addEffect(player, effect, 0);
            }
        }
    }

    private static void addEffect(Player player, MobEffect effect, int amplifier) {
        if (DISABLED_EFFECTS.contains(effect)) {
            return;
        }
        MobEffectInstance current = player.getEffect(effect);
        if (current != null && current.getAmplifier() > amplifier) {
            return;
        }
        player.addEffect(new MobEffectInstance(effect, BUFF_DURATION, amplifier, false, false, true));
    }

    private static List<MobEffect> getBeneficialEffects() {
        if (beneficialEffects == null) {
            beneficialEffects = ForgeRegistries.MOB_EFFECTS.getValues().stream()
                    .filter(MobEffect::isBeneficial)
                    .filter(effect -> !DISABLED_EFFECTS.contains(effect))
                    .toList();
        }
        return beneficialEffects;
    }
}
