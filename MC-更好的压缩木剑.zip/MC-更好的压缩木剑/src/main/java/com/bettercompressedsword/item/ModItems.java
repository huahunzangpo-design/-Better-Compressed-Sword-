package com.bettercompressedsword.item;

import com.bettercompressedsword.BetterCompressedSword;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.common.ForgeTier;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.List;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, BetterCompressedSword.MODID);
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, BetterCompressedSword.MODID);

    public static final RegistryObject<Item> LUCKY_STONE =
            ITEMS.register("lucky_stone", LuckyStoneItem::new);

    public static final RegistryObject<Item> COMPRESSION_TALISMAN =
            ITEMS.register("compression_talisman", CompressionTalismanItem::new);

    public static final List<RegistryObject<Item>> COMPRESSED_STICKS = List.of(
            ITEMS.register("compressed_stick_1", () -> new CompressedStickItem(1)),
            ITEMS.register("compressed_stick_2", () -> new CompressedStickItem(2)),
            ITEMS.register("compressed_stick_3", () -> new CompressedStickItem(3)),
            ITEMS.register("compressed_stick_4", () -> new CompressedStickItem(4)),
            ITEMS.register("compressed_stick_5", () -> new CompressedStickItem(5)),
            ITEMS.register("compressed_stick_6", () -> new CompressedStickItem(6))
    );

    // Minecraft中剑的最终攻击力 = 1 + tier.attackDamageBonus + SwordItem构造参数attackDamage
    // 最终攻击速度 = 4.0 + SwordItem构造参数attackSpeed
    // 这里将tier.attackDamageBonus设为0，攻击力完全由SwordItem参数控制
    // 注意：剑必须 stacksTo(1)，否则 Item.isEnchantable 默认返回 false，附魔台也要求物品数量为1
    public static final List<RegistryObject<Item>> COMPRESSED_WOODEN_SWORDS = List.of(
            // 一级：攻击10 攻速10
            ITEMS.register("compressed_wooden_sword_1", () -> new SwordItem(swordTier(1), 9, 6.0F, swordProperties())),
            // 二级：攻击35 攻速20
            ITEMS.register("compressed_wooden_sword_2", () -> new SwordItem(swordTier(2), 34, 16.0F, swordProperties())),
            // 三级：攻击66 攻速50
            ITEMS.register("compressed_wooden_sword_3", () -> new SwordItem(swordTier(3), 65, 46.0F, swordProperties())),
            // 四级：攻击266 攻速200，无限力量
            ITEMS.register("compressed_wooden_sword_4", () -> new CompressedWoodenSwordItem(4, swordTier(4), 265, 196.0F, swordProperties())),
            // 五级：攻击500 攻速600，无限力量
            ITEMS.register("compressed_wooden_sword_5", () -> new CompressedWoodenSwordItem(5, swordTier(5), 499, 596.0F, swordProperties())),
            // 六级：攻击10000 攻速10000，无限所有正面buff（不含生命提升与生命恢复）
            ITEMS.register("compressed_wooden_sword_6", () -> new CompressedWoodenSwordItem(6, swordTier(6), 9999, 9996.0F, swordProperties()))
    );

    public static final RegistryObject<CreativeModeTab> MOD_TAB = CREATIVE_MODE_TABS.register(
            "main",
            () -> CreativeModeTab.builder()
                    .withTabsBefore(CreativeModeTabs.COMBAT)
                    .title(Component.translatable("itemGroup.bettercompressedsword"))
                    .icon(() -> new ItemStack(getCompressedSword(6)))
                    .displayItems((parameters, output) -> {
                        output.accept(LUCKY_STONE.get());
                        output.accept(COMPRESSION_TALISMAN.get());
                        COMPRESSED_STICKS.forEach(item -> output.accept(item.get()));
                        COMPRESSED_WOODEN_SWORDS.forEach(item -> output.accept(item.get()));
                    })
                    .build()
    );

    private ModItems() {
    }

    private static Item.Properties swordProperties() {
        return new Item.Properties().stacksTo(1);
    }

    private static ForgeTier swordTier(int level) {
        return new ForgeTier(
                level,
                swordDurability(level),
                4.0F,
                0.0F,
                15,
                BlockTags.NEEDS_DIAMOND_TOOL,
                () -> Ingredient.of(getCompressedStick(level))
        );
    }

    private static int swordDurability(int level) {
        return switch (level) {
            case 1 -> 100;
            case 2 -> 300;
            case 3 -> 666;
            case 4 -> 999;
            case 5 -> 1666;
            case 6 -> 6666;
            default -> throw new IllegalArgumentException("Unknown sword level: " + level);
        };
    }

    public static Item getCompressedStick(int level) {
        if (level < 1 || level > COMPRESSED_STICKS.size()) {
            throw new IllegalArgumentException("Compressed stick level must be between 1 and 6: " + level);
        }
        return COMPRESSED_STICKS.get(level - 1).get();
    }

    public static Item getCompressedSword(int level) {
        if (level < 1 || level > COMPRESSED_WOODEN_SWORDS.size()) {
            throw new IllegalArgumentException("Compressed sword level must be between 1 and 6: " + level);
        }
        return COMPRESSED_WOODEN_SWORDS.get(level - 1).get();
    }
}
