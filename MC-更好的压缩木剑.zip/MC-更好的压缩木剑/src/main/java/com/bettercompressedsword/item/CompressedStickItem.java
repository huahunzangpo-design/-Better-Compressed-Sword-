package com.bettercompressedsword.item;

import com.bettercompressedsword.recipe.CompressionRecipe;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public final class CompressedStickItem extends Item {
    private final int level;

    public CompressedStickItem(int level) {
        super(new Item.Properties());
        this.level = level;
    }

    public int getLevel() {
        return level;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable(
                "tooltip.bettercompressedsword.compressed_stick.level", this.level
        ).withStyle(ChatFormatting.GRAY));

        if (this.level < 6) {
            tooltip.add(Component.translatable("tooltip.bettercompressedsword.compressed_stick.usage")
                    .withStyle(ChatFormatting.DARK_GRAY));
            tooltip.add(Component.translatable(
                    "tooltip.bettercompressedsword.compressed_stick.next_chance",
                    CompressionRecipe.getBaseChance(this.level)
            ).withStyle(ChatFormatting.YELLOW));
            tooltip.add(Component.translatable("tooltip.bettercompressedsword.compressed_stick.luck")
                    .withStyle(ChatFormatting.AQUA));
        } else {
            tooltip.add(Component.translatable("tooltip.bettercompressedsword.compressed_stick.final")
                    .withStyle(ChatFormatting.GOLD));
        }
    }
}
