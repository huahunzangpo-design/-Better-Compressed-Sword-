package com.bettercompressedsword.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * 压缩保护符：参与压缩/铸剑时，失败则保护所有材料、自身碎裂；成功则自身保留。
 */
public final class CompressionTalismanItem extends Item {
    public CompressionTalismanItem() {
        super(new Item.Properties());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.bettercompressedsword.compression_talisman")
                .withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.translatable("tooltip.bettercompressedsword.compression_talisman.recipe.title")
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.bettercompressedsword.compression_talisman.recipe.materials")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
