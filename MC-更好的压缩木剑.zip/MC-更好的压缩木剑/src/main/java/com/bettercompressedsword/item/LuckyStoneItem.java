package com.bettercompressedsword.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public final class LuckyStoneItem extends Item {
    public LuckyStoneItem() {
        super(new Item.Properties());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.bettercompressedsword.lucky_stone")
                .withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.translatable("tooltip.bettercompressedsword.lucky_stone.recipe.title")
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.bettercompressedsword.lucky_stone.recipe.materials")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
